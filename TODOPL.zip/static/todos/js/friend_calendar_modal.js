console.log(
    'friend_calendar_modal.js 로드됨'
);


/* ============================================================
   전역 상태
============================================================ */

let FriendCalendarModal = null;

let FriendCalendarTitle = null;

let FriendCalendarCloseButton = null;

let FriendCalendarGrid = null;

let FriendCalendarTodoDate = null;

let FriendCalendarTodoList = null;


/*
    현재 열려 있는 친구 정보
*/

let CurrentFriendObject = null;


/*
    현재 선택된 날짜
*/

let SelectedFriendCalendarDate = null;


/* ============================================================
   친구 캘린더 모달 초기화
============================================================ */

function Initialize_Friend_Calendar_Modal() {

    console.log(
        '친구 캘린더 모달 초기화'
    );


    FriendCalendarModal = document.getElementById(
        'FriendCalendarModal'
    );


    FriendCalendarTitle = document.getElementById(
        'FriendCalendarTitle'
    );


    FriendCalendarCloseButton = document.getElementById(
        'FriendCalendarCloseButton'
    );


    FriendCalendarGrid = document.getElementById(
        'FriendCalendarGrid'
    );


    FriendCalendarTodoDate = document.getElementById(
        'FriendCalendarTodoDate'
    );


    FriendCalendarTodoList = document.getElementById(
        'FriendCalendarTodoList'
    );


    /*
        모달이 아직 존재하지 않는 경우
    */

    if (
        !FriendCalendarModal
    ) {

        console.warn(
            'FriendCalendarModal 요소를 찾을 수 없습니다.'
        );

        return;

    }


    /*
        캘린더 영역 확인
    */

    if (
        !FriendCalendarGrid
    ) {

        console.warn(
            'FriendCalendarGrid 요소를 찾을 수 없습니다.'
        );

        return;

    }


    /*
        닫기 버튼
    */

    if (
        FriendCalendarCloseButton
    ) {

        FriendCalendarCloseButton.addEventListener(
            'click',
            Close_Friend_Calendar
        );

    }


    /*
        모달 바깥쪽 클릭 시 닫기
    */

    FriendCalendarModal.addEventListener(
        'click',
        (
            Event
        ) => {

            if (
                Event.target === FriendCalendarModal
            ) {

                Close_Friend_Calendar();

            }

        }
    );


    /*
        ESC 키로 닫기
    */

    document.addEventListener(
        'keydown',
        (
            Event
        ) => {

            if (
                Event.key === 'Escape'
                &&
                FriendCalendarModal
                &&
                !FriendCalendarModal.classList.contains(
                    'hidden'
                )
            ) {

                Close_Friend_Calendar();

            }

        }
    );


    /*
        초기 상태
    */

    Reset_Friend_Calendar_State();

}


/* ============================================================
   친구 캘린더 열기
============================================================ */

function Open_Friend_Calendar(
    FriendObject
) {

    console.log(
        '친구 캘린더 열기:',
        FriendObject
    );


    /*
        친구 객체 확인
    */

    if (
        !FriendObject
    ) {

        console.error(
            '친구 정보가 전달되지 않았습니다.'
        );

        return;

    }


    /*
        모달이 초기화되지 않은 경우
    */

    if (
        !FriendCalendarModal
    ) {

        console.warn(
            'FriendCalendarModal이 초기화되지 않았습니다. 다시 초기화합니다.'
        );

        Initialize_Friend_Calendar_Modal();

    }


    if (
        !FriendCalendarModal
    ) {

        console.error(
            '친구 캘린더 모달을 초기화할 수 없습니다.'
        );

        return;

    }


    /*
        친구 정보 저장
    */

    CurrentFriendObject = FriendObject;


    /*
        친구 ID 확인

        friend_list.js에서 어떤 이름으로 전달되더라도
        최대한 안전하게 처리한다.
    */

    const FriendId = (
        FriendObject.user_id
        ??
        FriendObject.friend_id
        ??
        FriendObject.id
    );


    console.log(
        '친구 캘린더 친구 ID:',
        FriendId
    );


    if (
        FriendId === null
        ||
        FriendId === undefined
        ||
        FriendId === ''
    ) {

        console.error(
            '친구 ID를 찾을 수 없습니다.',
            FriendObject
        );

        CurrentFriendObject = null;

        return;

    }


    /*
        현재 객체에 friend_id를 통일해서 저장

        이후 날짜 클릭 시 이 값을 사용한다.
    */

    CurrentFriendObject = {
        ...FriendObject,
        friend_id: FriendId
    };


    /*
        이전 선택 날짜 초기화
    */

    SelectedFriendCalendarDate = null;


    /*
        친구 닉네임
    */

    const FriendNickname = (
        FriendObject.nickname
        ||
        '친구'
    );


    /*
        상단 제목
    */

    if (
        FriendCalendarTitle
    ) {

        FriendCalendarTitle.textContent = (
            `${FriendNickname}님의 캘린더`
        );

    }


    /*
        날짜 선택 표시 초기화
    */

    if (
        FriendCalendarTodoDate
    ) {

        FriendCalendarTodoDate.textContent = (
            '날짜를 선택해주세요.'
        );

    }


    /*
        Todo 목록 초기화
    */

    if (
        FriendCalendarTodoList
    ) {

        FriendCalendarTodoList.innerHTML = '';

    }


    /*
        현재 달 캘린더 생성

        중요:
        오늘 날짜를 자동 선택하지 않는다.
    */

    Render_Friend_Calendar();


    /*
        모달 표시
    */

    FriendCalendarModal.classList.remove(
        'hidden'
    );


    FriendCalendarModal.classList.add(
        'flex'
    );


    /*
        배경 스크롤 방지
    */

    document.body.classList.add(
        'overflow-hidden'
    );

}


/* ============================================================
   친구 캘린더 닫기
============================================================ */

function Close_Friend_Calendar() {

    if (
        !FriendCalendarModal
    ) {

        return;

    }


    FriendCalendarModal.classList.add(
        'hidden'
    );


    FriendCalendarModal.classList.remove(
        'flex'
    );


    document.body.classList.remove(
        'overflow-hidden'
    );


    /*
        닫을 때 상태 초기화
    */

    SelectedFriendCalendarDate = null;

    CurrentFriendObject = null;

}


/* ============================================================
   캘린더 상태 초기화
============================================================ */

function Reset_Friend_Calendar_State() {

    SelectedFriendCalendarDate = null;

    CurrentFriendObject = null;


    if (
        FriendCalendarGrid
    ) {

        FriendCalendarGrid.innerHTML = '';

    }


    if (
        FriendCalendarTodoDate
    ) {

        FriendCalendarTodoDate.textContent = (
            '날짜를 선택해주세요.'
        );

    }


    if (
        FriendCalendarTodoList
    ) {

        FriendCalendarTodoList.innerHTML = '';

    }

}


/* ============================================================
   현재 달 캘린더 생성
============================================================ */

function Render_Friend_Calendar() {

    if (
        !FriendCalendarGrid
    ) {

        console.warn(
            'FriendCalendarGrid 요소가 없습니다.'
        );

        return;

    }


    FriendCalendarGrid.innerHTML = '';


    /*
        현재 날짜 기준으로 현재 달 결정
    */

    const Today = new Date();


    const CurrentYear = (
        Today.getFullYear()
    );


    const CurrentMonth = (
        Today.getMonth()
    );


    /*
        현재 달 1일
    */

    const FirstDay = new Date(
        CurrentYear,
        CurrentMonth,
        1
    );


    /*
        현재 달 마지막 날짜
    */

    const LastDate = new Date(
        CurrentYear,
        CurrentMonth + 1,
        0
    ).getDate();


    /*
        1일의 요일

        일요일 = 0
        월요일 = 1
        ...
        토요일 = 6
    */

    const StartDay = (
        FirstDay.getDay()
    );


    /*
        첫 번째 빈칸
    */

    for (
        let Index = 0;
        Index < StartDay;
        Index++
    ) {

        const EmptyElement = document.createElement(
            'div'
        );


        EmptyElement.className = (
            'h-10'
        );


        FriendCalendarGrid.appendChild(
            EmptyElement
        );

    }


    /*
        날짜 생성
    */

    for (
        let DateNumber = 1;
        DateNumber <= LastDate;
        DateNumber++
    ) {

        const DateButton = document.createElement(
            'button'
        );


        DateButton.type = (
            'button'
        );


        /*
            기본 상태

            오늘 날짜라고 해서
            자동으로 선택하지 않는다.
        */

        DateButton.className = `
            flex
            h-10
            w-full
            items-center
            justify-center
            rounded-full
            text-sm
            font-semibold
            text-gray-700
            transition
            hover:bg-gray-100
            active:scale-95
        `;


        DateButton.textContent = (
            DateNumber
        );


        /*
            YYYY-MM-DD
        */

        const MonthString = String(
            CurrentMonth + 1
        ).padStart(
            2,
            '0'
        );


        const DateString = String(
            DateNumber
        ).padStart(
            2,
            '0'
        );


        const FullDateString = (
            `${CurrentYear}-${MonthString}-${DateString}`
        );


        DateButton.dataset.date = (
            FullDateString
        );


        /*
            날짜 클릭
        */

        DateButton.addEventListener(
            'click',
            () => {

                Select_Friend_Calendar_Date(
                    DateButton,
                    FullDateString
                );

            }
        );


        FriendCalendarGrid.appendChild(
            DateButton
        );

    }

}


/* ============================================================
   날짜 선택
============================================================ */

function Select_Friend_Calendar_Date(
    DateButton,
    SelectedDateString
) {

    console.log(
        '친구 캘린더 날짜 선택:',
        SelectedDateString
    );


    /*
        친구 정보 확인
    */

    if (
        !CurrentFriendObject
    ) {

        console.error(
            '현재 친구 정보가 없습니다.'
        );

        return;

    }


    /*
        친구 ID 확인
    */

    const FriendId = (
        CurrentFriendObject.friend_id
        ??
        CurrentFriendObject.user_id
        ??
        CurrentFriendObject.id
    );


    console.log(
        '선택 날짜 친구 ID:',
        FriendId
    );


    if (
        FriendId === null
        ||
        FriendId === undefined
        ||
        FriendId === ''
    ) {

        console.error(
            '친구 ID가 없습니다.',
            CurrentFriendObject
        );

        return;

    }


    /*
        이전 날짜 선택 효과 제거
    */

    Clear_Friend_Calendar_Date_Selection();


    /*
        현재 선택 날짜 저장
    */

    SelectedFriendCalendarDate = (
        SelectedDateString
    );


    /*
        선택된 날짜에만 효과 적용
    */

    DateButton.classList.remove(
        'text-gray-700'
    );


    DateButton.classList.add(
        'bg-indigo-50',
        'text-indigo-600'
    );


    /*
        선택 날짜 표시
    */

    Update_Friend_Calendar_Todo_Date(
        SelectedDateString
    );


    /*
        해당 날짜의 친구 Todo 조회
    */

    Load_Friend_Calendar_Todos(
        FriendId,
        SelectedDateString
    );

}


/* ============================================================
   날짜 선택 스타일 제거
============================================================ */

function Clear_Friend_Calendar_Date_Selection() {

    if (
        !FriendCalendarGrid
    ) {

        return;

    }


    const DateButtons = (
        FriendCalendarGrid.querySelectorAll(
            'button[data-date]'
        )
    );


    DateButtons.forEach(
        (
            DateButton
        ) => {

            DateButton.classList.remove(
                'bg-indigo-50',
                'text-indigo-600'
            );


            DateButton.classList.add(
                'text-gray-700'
            );

        }
    );

}


/* ============================================================
   선택 날짜 표시
============================================================ */

function Update_Friend_Calendar_Todo_Date(
    SelectedDateString
) {

    if (
        !FriendCalendarTodoDate
    ) {

        return;

    }


    const SelectedDate = new Date(
        `${SelectedDateString}T00:00:00`
    );


    const Year = (
        SelectedDate.getFullYear()
    );


    const Month = String(
        SelectedDate.getMonth() + 1
    ).padStart(
        2,
        '0'
    );


    const DateNumber = String(
        SelectedDate.getDate()
    ).padStart(
        2,
        '0'
    );


    FriendCalendarTodoDate.textContent = (
        `${Year}.${Month}.${DateNumber}`
    );

}


/* ============================================================
   친구 Todo 조회 API
============================================================ */

async function Load_Friend_Calendar_Todos(
    FriendId,
    SelectedDateString
) {

    if (
        !FriendCalendarTodoList
    ) {

        console.warn(
            'FriendCalendarTodoList 요소가 없습니다.'
        );

        return;

    }


    /*
        친구 ID 확인
    */

    if (
        FriendId === null
        ||
        FriendId === undefined
        ||
        FriendId === ''
    ) {

        console.error(
            '친구 Todo 조회에 필요한 친구 ID가 없습니다.'
        );

        Render_Friend_Calendar_Todo_Error(
            '친구 정보를 확인할 수 없습니다.'
        );

        return;

    }


    /*
        조회 중 표시
    */

    Render_Friend_Calendar_Todo_Loading();


    try {

        /*
            API URL

            Django:
            path(
                'friend-calendar/',
                views.friend_calendar_todos,
                name='friend_calendar_todos'
            )
        */

        const ApiUrl = (
            `/friend-calendar/?friend_id=${encodeURIComponent(
                FriendId
            )}&date=${encodeURIComponent(
                SelectedDateString
            )}`
        );


        console.log(
            '친구 캘린더 Todo 조회 URL:',
            ApiUrl
        );


        const Response = await fetch(
            ApiUrl,
            {
                method: 'GET',

                headers: {
                    'X-Requested-With': 'XMLHttpRequest'
                }
            }
        );


        /*
            응답 원본을 먼저 text로 받는다.
        */

        const ResponseText = await Response.text();


        console.log(
            '친구 캘린더 응답 상태:',
            Response.status
        );


        console.log(
            '친구 캘린더 원본 응답:',
            ResponseText
        );


        let Data = {};


        /*
            JSON 변환
        */

        if (
            ResponseText
        ) {

            try {

                Data = JSON.parse(
                    ResponseText
                );

            }

            catch (
                JsonError
            ) {

                console.error(
                    '친구 캘린더 JSON 변환 실패:',
                    JsonError
                );


                throw new Error(
                    '친구 캘린더 서버 응답을 처리할 수 없습니다.'
                );

            }

        }


        /*
            HTTP 상태 또는 success 확인
        */

        if (
            !Response.ok
            ||
            !Data.success
        ) {

            throw new Error(
                Data.message
                ||
                `친구 할 일을 불러오지 못했습니다. (HTTP ${Response.status})`
            );

        }


        console.log(
            '친구 캘린더 Todo 조회 성공:',
            Data.todos
        );


        /*
            Todo 표시
        */

        Render_Friend_Calendar_Todos(
            Data.todos
        );

    }

    catch (
        Error
    ) {

        console.error(
            '친구 캘린더 Todo 조회 실패:',
            Error
        );


        Render_Friend_Calendar_Todo_Error(
            Error.message
        );

    }

}


/* ============================================================
   Todo 로딩 표시
============================================================ */

function Render_Friend_Calendar_Todo_Loading() {

    if (
        !FriendCalendarTodoList
    ) {

        return;

    }


    FriendCalendarTodoList.innerHTML = `

        <div
            class='
                rounded-2xl
                bg-gray-50
                px-4
                py-5
                text-center
            '
        >

            <p
                class='
                    text-sm
                    font-medium
                    text-gray-400
                '
            >
                할 일을 불러오는 중입니다.
            </p>

        </div>

    `;

}


/* ============================================================
   Todo 목록 렌더링
============================================================ */

function Render_Friend_Calendar_Todos(
    TodoList
) {

    if (
        !FriendCalendarTodoList
    ) {

        return;

    }


    FriendCalendarTodoList.innerHTML = '';


    /*
        Todo가 없는 경우
    */

    if (
        !TodoList
        ||
        TodoList.length === 0
    ) {

        FriendCalendarTodoList.innerHTML = `

            <div
                class='
                    rounded-2xl
                    bg-gray-50
                    px-4
                    py-5
                    text-center
                '
            >

                <p
                    class='
                        text-sm
                        font-medium
                        text-gray-400
                    '
                >
                    등록된 할 일이 없습니다.
                </p>

            </div>

        `;

        return;

    }


    /*
        Todo 생성
    */

    TodoList.forEach(
        (
            TodoObject
        ) => {

            const TodoElement = document.createElement(
                'div'
            );


            TodoElement.className = `
                flex
                items-center
                gap-3
                rounded-2xl
                border
                border-gray-100
                bg-white
                px-4
                py-3
            `;


            /*
                완료 여부
            */

            const IsCompleted = (
                TodoObject.is_completed
            );


            /*
                Todo 제목
            */

            const TodoTitle = (
                TodoObject.title
                ||
                '제목 없음'
            );


            /*
                Todo 시간
            */

            const TodoTime = (
                TodoObject.todo_time
                ||
                ''
            );


            /*
                Todo HTML
            */

            TodoElement.innerHTML = `

                <div
                    class='
                        flex
                        h-8
                        w-8
                        flex-shrink-0
                        items-center
                        justify-center
                        rounded-full
                        bg-gray-50
                    '
                >

                    <i
                        class='
                            fa-solid
                            fa-check
                            text-xs
                            text-gray-400
                        '
                    ></i>

                </div>


                <div
                    class='
                        min-w-0
                        flex-1
                    '
                >

                    <p
                        class='
                            truncate
                            text-sm
                            font-semibold
                            ${
                                IsCompleted
                                ?
                                'text-gray-400 line-through'
                                :
                                'text-gray-700'
                            }
                        '
                    >
                        ${Escape_Friend_Calendar_Html(
                            TodoTitle
                        )}
                    </p>


                    ${
                        TodoTime
                        ?
                        `
                            <p
                                class='
                                    mt-0.5
                                    text-xs
                                    font-medium
                                    text-gray-400
                                '
                            >
                                ${Escape_Friend_Calendar_Html(
                                    TodoTime
                                )}
                            </p>
                        `
                        :
                        ''
                    }

                </div>

            `;


            FriendCalendarTodoList.appendChild(
                TodoElement
            );

        }
    );

}


/* ============================================================
   Todo 조회 오류 표시
============================================================ */

function Render_Friend_Calendar_Todo_Error(
    ErrorMessage
) {

    if (
        !FriendCalendarTodoList
    ) {

        return;

    }


    FriendCalendarTodoList.innerHTML = `

        <div
            class='
                rounded-2xl
                border
                border-red-100
                bg-red-50
                px-4
                py-5
                text-center
            '
        >

            <p
                class='
                    text-sm
                    font-bold
                    text-red-500
                '
            >
                친구 할 일을 불러오지 못했습니다.
            </p>

        </div>

    `;


    console.error(
        '친구 캘린더 오류:',
        ErrorMessage
    );

}


/* ============================================================
   HTML 이스케이프
============================================================ */

function Escape_Friend_Calendar_Html(
    Value
) {

    if (
        Value === null
        ||
        Value === undefined
    ) {

        return '';

    }


    const Element = document.createElement(
        'div'
    );


    Element.textContent = (
        String(Value)
    );


    return Element.innerHTML;

}


/* ============================================================
   초기화
============================================================ */

if (
    document.readyState === 'loading'
) {

    document.addEventListener(
        'DOMContentLoaded',
        Initialize_Friend_Calendar_Modal
    );

}

else {

    Initialize_Friend_Calendar_Modal();

}